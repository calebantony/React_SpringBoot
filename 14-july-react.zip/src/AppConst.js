 export const USER_API_URL = "http://localhost:8082/";
 export const ADMIN_API_URL = "http://localhost:8084/";
 export const AUTH_API_URL = "http://localhost:8081/";
 export const FLAT_API_URL = "http://localhost:8083/";
package com.flatService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlatServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
